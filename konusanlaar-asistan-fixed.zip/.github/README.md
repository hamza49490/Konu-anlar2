---------------------

- <b> [ ᴛᴇʟᴇɢʀᴀᴍ sᴜᴘᴘᴏʀᴛ ](https://t.me/BotsDestek)
 
- <b> [ ʏᴏᴜᴛᴜʙᴇ ᴄʜᴀɴɴᴇʟ ](https://youtube.com/@EpikTv87?si=bugHmTi6CzaBu8v4)

- _[ ɢɪ̇ᴛʜᴜʙ ᴍᴜsɪ̇ᴄ ](https://github.com/MehmetAtes21/Pi)_
 </b>

 -----------------

- SAHİP KOMUTLARI :

-------------------

- /sudoekle - Sudo kullanıcı ekle .
- /sudosil - Sudo kullanıcı sil .
- /sudolist - Sudo kullanıcı listesi .

- /reklam - Gruplara Reklam Atar !

- /karasohbet - Grubu kara listeye alır !

- /beyazsohbet - Grubu beyaz listeye alır !

- /sohbetlist - Kara listedeki grupları görün !

- /karakullanici - Kullanıcıyı kara listeye alır !

- /beyazkullanici Kullanıcıyı beyaz listeye alır !

- /kullanicilist - Kara listedeki kullanıcıları görün !

- /logger enable - Günlük logu aktif edin !

- /logger disable - Günlük logu kapatın !

- /aktifses - Aktif sesli sohbetleri görün !

- /aktifvideo - Aktif videolu sohbetleri görün !

- /hiztest - Botun hızını test edin !

- /ping - Botun pingine göz atın !

- /reboot - Botunuza reset atın !
